## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(dplyr)
library(ggplot2)
library(scrubR)


## ----clean-swim-data, eval = FALSE--------------------------------------------
# data <- read.csv("/cloud/project/data-raw/Olympic_Swimming_Results_1912to2020.csv")
# 
# swimming_data_cleaned <- clean_swim_data(data, rename_columns = TRUE, verbose = TRUE)
# 
# head(swimming_data_cleaned)
# 

## ----join_sheets--------------------------------------------------------------
# Load and join the mouse data Excel sheets
file_path <- "/cloud/project/inst/extdata/mousedata.xlsx"
if (file.exists(file_path)) {
  joined_data <- join_sheets(file_path, "ID", c("Birth", "Body Weight", "Outcome"))
  head(joined_data)
} else {
  message("File does not exist. Please verify the path.")
}


## ----categorical-check--------------------------------------------------------
# Check the "Body Weight 3" column for non-numerical values
if (exists("joined_data")) {
  quantitative_issues <- quantitative_check(joined_data, "Body Weight 3")
  quantitative_issues
}

## ----join-sheets, eval=FALSE--------------------------------------------------
# # Check the "Treatment" column for valid values
# if (exists("joined_data")) {
#   categorical_issues <- categorical_check(joined_data, "Treatment", c("Alive", "Dead"))
#   categorical_issues
# }
# 

## ----plot-change, eval=FALSE--------------------------------------------------
# # Visualize changes in body weight for the mouse dataset
# if (exists("joined_data")) {
#   plot <- plot_change(
#     data = joined_data,
#     id_col = "ID",
#     var_cols = c("Body Weight 1", "Body Weight 2", "Body Weight 3"),
#     color = "Treatment",
#     cat = "Treatment"
#   )
#   plot
# }

