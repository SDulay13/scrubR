utils::globalVariables(c(
  "ID", "Observed_Value", "Error_Message", "Location", "Year",
  "Distance..in.meters.", "Stroke", "Relay.", "Gender", "Team",
  "Athlete", "Results", "Rank", "relay", "distance_in_meters",
  "parsed_relay_distance", "results", "total_distance_in_meters",
  "sheet_name", "Value", "Value_Drop"
))
